package com.user.security.auth.service;

import com.user.security.auth.model.Role;
import com.user.security.auth.model.User;
import com.user.security.auth.repository.RoleRepository;
import com.user.security.auth.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;

	@Override
	public void save(User user) {
		userRepository.save(user);
	}

	@Override
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public List<Role> findRoleAll() {
		return roleRepository.findAll();
	}

	@Override
	public void saveRole(Role role) {
		roleRepository.save(role);

	}

	@Override
	public void savePassword(User user) {
		userRepository.save(user);
		
	}

	@Override
	public void delete(User user) {
		userRepository.delete(user);
		
	}
	
	
}
