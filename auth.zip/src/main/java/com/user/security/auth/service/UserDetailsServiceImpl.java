package com.user.security.auth.service;

import com.user.security.auth.model.Credentail;
import com.user.security.auth.model.Role;
import com.user.security.auth.model.User;
import com.user.security.auth.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	@Autowired
	private UserRepository userRepository;

	@Override
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUsername(username);

		Collection<Credentail> credentails = user.getCredentails();
		String password = null;
		for (Credentail credentail : credentails) {
			if (credentail.getCridentailType().equals("PASSWORD")) {
				password = credentail.getCridentailValue();
				break;
			}
		}

		Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
		Set<String> duplicate = new HashSet<>();
		for (Role role : user.getRoles()) {
			if (!duplicate.contains(role.getId())) {
				System.out.println("role.getId() >>>" + role.getId());
				grantedAuthorities.add(new SimpleGrantedAuthority(role.getId()));
				duplicate.add(role.getId());
			}
		}

		return new org.springframework.security.core.userdetails.User(user.getUsername(), password, grantedAuthorities);
	}
}
