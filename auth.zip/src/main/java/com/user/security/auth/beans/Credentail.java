package com.user.security.auth.beans;

public class Credentail {

	private String cridentailType;

	private String cridentailValue;

	private String secondaryId;

	public Credentail() {

	}

	public Credentail(String cridentailType) {
		this.cridentailType = cridentailType;
	}

	public String getCridentailType() {
		return cridentailType;
	}

	public void setCridentailType(String cridentailType) {
		this.cridentailType = cridentailType;
	}

	public String getCridentailValue() {
		return cridentailValue;
	}

	public void setCridentailValue(String cridentailValue) {
		this.cridentailValue = cridentailValue;
	}

	public String getSecondaryId() {
		return secondaryId;
	}

	public void setSecondaryId(String secondaryId) {
		this.secondaryId = secondaryId;
	}

}
