package com.user.security.auth.model;

import javax.persistence.*;
import java.util.Collection;
import java.util.ArrayList;

@Entity
@Table(name = "USER_DESC")
public class User {

	@Id
	@Column(name = "PRINCIPAL_ID", nullable = false)
	private String username;
	
	@Column(name = "NAMESPACE")
	private String namespace;
	
	@OneToMany
    @JoinTable( name="USER_ROLE", 
                joinColumns=@JoinColumn(name="PRINCIPAL_ID"), 
                inverseJoinColumns=@JoinColumn(name="AUTHORIZATION_ID"))
	private Collection<Role> roles = new ArrayList<Role>();
	
	@ElementCollection(fetch = FetchType.LAZY)
	@JoinTable(name = "USER_CREDENTIAL", joinColumns = @JoinColumn(name = "PRINCIPAL_ID"))
	private Collection<Credentail> credentails = new ArrayList<Credentail>();

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Collection<Credentail> getCredentails() {
		return credentails;
	}

	public void setCredentails(Collection<Credentail> credentails) {
		this.credentails = credentails;
	}

	public Collection<Role> getRoles() {
		return roles;
	}

	public void setRoles(Collection<Role> roles) {
		this.roles = roles;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
}
