package com.user.security.auth.model;

import javax.persistence.*;

@Entity
@Table(name = "USER_AUTHORIZATION")
public class Role {

	@Id
	@Column(name = "AUTHORIZATION_ID")
	private String id;

	@Column(name = "AUTHORIZATION_DESC")
	private String description;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
