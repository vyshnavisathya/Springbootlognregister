package com.user.security.auth.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable
public class Credentail {

	@Column(name = "CREDENTIAL_ID", nullable = false)
	private String cridentailId;

	@Column(name = "CREDENTIAL_TYPE")
	private String cridentailType;

	@Column(name = "CREDENTIAL_VALUE")
	private String cridentailValue;

	@Column(name = "SECODARY_ID")
	private String secondaryId;

	public String getCridentailId() {
		return cridentailId;
	}

	public void setCridentailId(String cridentailId) {
		this.cridentailId = cridentailId;
	}

	public String getCridentailType() {
		return cridentailType;
	}

	public void setCridentailType(String cridentailType) {
		this.cridentailType = cridentailType;
	}

	public String getCridentailValue() {
		return cridentailValue;
	}

	public void setCridentailValue(String cridentailValue) {
		this.cridentailValue = cridentailValue;
	}

	public String getSecondaryId() {
		return secondaryId;
	}

	public void setSecondaryId(String secondaryId) {
		this.secondaryId = secondaryId;
	}

}
