package com.user.security.auth.service;

import java.util.List;

import com.user.security.auth.model.Role;
import com.user.security.auth.model.User;

public interface UserService {
	void save(User user);

	User findByUsername(String username);

	List<Role> findRoleAll();

	void saveRole(Role role);
	
	void savePassword(User user);
	
	void delete(User user);

}
