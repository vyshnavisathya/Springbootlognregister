package com.user.security.auth.beans;

public class User {
	private String username;
	private String password;
	private String passwordConfirm;
	private String[] role;
	private String namespace;
	
	private Credentail fingerPrintCredentail= new Credentail("FINGER_PRINT");

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordConfirm() {
		return passwordConfirm;
	}

	public void setPasswordConfirm(String passwordConfirm) {
		this.passwordConfirm = passwordConfirm;
	}

	public String[] getRole() {
		return role;
	}

	public void setRole(String[] role) {
		this.role = role;
	}

	public Credentail getFingerPrintCredentail() {
		return fingerPrintCredentail;
	}

	public void setFingerPrintCredentail(Credentail fingerPrintCredentail) {
		this.fingerPrintCredentail = fingerPrintCredentail;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
}
