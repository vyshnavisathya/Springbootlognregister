package com.user.security.auth.web;

import com.user.security.auth.model.Credentail;
import com.user.security.auth.model.Role;
import com.user.security.auth.model.User;
import com.user.security.auth.repository.RoleRepository;
import com.user.security.auth.service.SecurityService;
import com.user.security.auth.service.UserService;
import com.user.security.auth.validator.UserValidator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@SessionAttributes("user")
public class UserController {

	private static boolean fistTime = true;
	@Autowired
	private UserService userService;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserValidator userValidator;

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String registration(Model model) {

		model.addAttribute("roleList", getRoleList());
		model.addAttribute("userForm", new com.user.security.auth.beans.User());

		return "registration";
	}

	@RequestMapping(value = "/addrole", method = RequestMethod.GET)
	public String addRole(Model model) {

		model.addAttribute("roleForm", new com.user.security.auth.beans.Role());

		return "addrole";
	}

	@ModelAttribute("roleList")
	public List<Role> getRoleList() {
		if (fistTime) {
			Role rol1 = new Role();
			rol1.setId("ROLE_ADMIN");
			rol1.setDescription("Admin Role");

			Role rol2 = new Role();
			rol2.setId("ROLE_USER");
			rol2.setDescription("User Role");
			userService.saveRole(rol1);
			userService.saveRole(rol2);
			fistTime = false;

		}
		return userService.findRoleAll();
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registration(@ModelAttribute("userForm") com.user.security.auth.beans.User userForm,
			BindingResult bindingResult, Model model) {
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			return "registration";
		}

		User user = new User();
		user.setUsername(userForm.getUsername());
		user.setNamespace(userForm.getNamespace());

		Collection<Role> roles = new ArrayList<Role>();
		for (Role roleObj : roleRepository.findAll()) {
			for (String role : userForm.getRole()) {
				if (roleObj.getId().equals(role)) {
					roles.add(roleObj);
				}
			}
		}
		user.setRoles(roles);

		com.user.security.auth.model.Credentail credentail1 = new com.user.security.auth.model.Credentail();
		credentail1.setCridentailId(userForm.getUsername() + "PASSWORD");
		credentail1.setCridentailType("PASSWORD");
		credentail1.setCridentailValue(bCryptPasswordEncoder.encode(userForm.getPassword()));
		credentail1.setSecondaryId("Null");

		com.user.security.auth.model.Credentail credentail2 = new com.user.security.auth.model.Credentail();
		credentail2.setCridentailValue(userForm.getFingerPrintCredentail().getCridentailValue());
		credentail2.setCridentailType("FINGER_PRINT");
		credentail2.setCridentailId(userForm.getUsername() + "FINGER_PRINT");
		credentail2.setSecondaryId(userForm.getFingerPrintCredentail().getSecondaryId());

		Collection<Credentail> credentails = new ArrayList<Credentail>();
		credentails.add(credentail1);
		credentails.add(credentail2);

		user.setCredentails(credentails);

		userService.save(user);

		securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());

		return "redirect:/welcome";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");

		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");

		return "login";
	}

	@RequestMapping(value = { "/", "/welcome" }, method = RequestMethod.GET)
	public String welcome(Model model) {
		return "welcome";
	}

	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied() {
		ModelAndView model = new ModelAndView();
		model.addObject("msg", "You do not have permission to access this page!");
		model.setViewName("403");
		return model;
	}

	@RequestMapping(value = "/createuser", method = RequestMethod.GET)
	public String createUser(Model model) {

		model.addAttribute("roleList", getRoleList());
		model.addAttribute("createUserForm", new com.user.security.auth.beans.User());

		return "CreateUser";
	}

	@RequestMapping(value = "/createuser", method = RequestMethod.POST)
	public String createUser(@ModelAttribute("createUserForm") com.user.security.auth.beans.User userForm,
			BindingResult bindingResult, Model model) {
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			return "CreateUser";
		}

		User user = new User();
		user.setUsername(userForm.getUsername());
		user.setNamespace(userForm.getNamespace());

		Collection<Role> roles = new ArrayList<Role>();
		for (Role roleObj : roleRepository.findAll()) {
			for (String role : userForm.getRole()) {
				if (roleObj.getId().equals(role)) {
					roles.add(roleObj);
				}
			}
		}
		user.setRoles(roles);

		com.user.security.auth.model.Credentail credentail1 = new com.user.security.auth.model.Credentail();
		credentail1.setCridentailId(userForm.getUsername() + "PASSWORD");
		credentail1.setCridentailType("PASSWORD");
		credentail1.setCridentailValue(bCryptPasswordEncoder.encode(userForm.getPassword()));
		credentail1.setSecondaryId("Null");

		com.user.security.auth.model.Credentail credentail2 = new com.user.security.auth.model.Credentail();
		credentail2.setCridentailValue(userForm.getFingerPrintCredentail().getCridentailValue());
		credentail2.setCridentailType("FINGER_PRINT");
		credentail2.setCridentailId(userForm.getUsername() + "FINGER_PRINT");
		credentail2.setSecondaryId(userForm.getFingerPrintCredentail().getSecondaryId());

		Collection<Credentail> credentails = new ArrayList<Credentail>();
		credentails.add(credentail1);
		credentails.add(credentail2);

		user.setCredentails(credentails);

		userService.save(user);

		securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());

		return "redirect:/welcome";
	}

	@RequestMapping(value = "/changepassword", method = RequestMethod.GET)
	public String changePassword(Model model) {
		model.addAttribute("password", new com.user.security.auth.beans.User());
		return "ChangePassword";
	}

	@RequestMapping(value = "/changepassword", method = RequestMethod.POST)
	public String changePassword(@ModelAttribute("password") com.user.security.auth.beans.User userForm,
			BindingResult bindingResult, Model model) {
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>-"+userForm.getPassword()+">"+securityService.findLoggedInUsername());
		
		User userModal = userService.findByUsername(securityService.findLoggedInUsername());
		for (Credentail credentail : userModal.getCredentails()) {
			if ("PASSWORD".equals(credentail.getCridentailType())) {
				credentail.setCridentailValue(bCryptPasswordEncoder.encode(userForm.getPassword()));
			}
		}
		userService.save(userModal);
		System.out.println("New Password Created for User");
		
		return "redirect:/welcome";
	}
	
	@RequestMapping(value = "/deleteuser", method = RequestMethod.GET)
	public String deleteUser(Model model) {
		model.addAttribute("deleteUser", new com.user.security.auth.beans.User());
		return "DeleteUser";
	}
	
	@RequestMapping(value = "/deleteuser", method = RequestMethod.POST)
	public String deleteUser(@ModelAttribute("deleteUser") com.user.security.auth.beans.User userForm,
			BindingResult bindingResult, Model model) {
		System.out.println("Username : "+ userForm.getUsername());
		
		User user = new User();
		user.setUsername(userForm.getUsername());
		userService.delete(user);
		
		return "redirect:/welcome";
	}

}
